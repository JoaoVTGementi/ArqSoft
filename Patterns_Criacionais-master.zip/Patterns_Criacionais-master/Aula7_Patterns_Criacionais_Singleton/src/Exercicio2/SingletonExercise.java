package Exercicio2;

public class SingletonExercise {
	public static void main(String args[]) {
		Deck deck = new Deck( );
		
		deck.print( );
		}

}
