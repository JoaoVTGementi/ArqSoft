# Patterns_Criacionais
Atividades
